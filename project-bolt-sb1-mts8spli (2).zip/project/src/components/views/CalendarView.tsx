import React from 'react';
import { Task } from '../../types';
import { formatDate } from '../../utils/dateUtils';

interface CalendarViewProps {
  tasks: Task[];
  onTaskClick: (task: Task) => void;
}

export function CalendarView({ tasks, onTaskClick }: CalendarViewProps) {
  const tasksByDate = tasks.reduce((acc, task) => {
    if (task.dueDate) {
      const date = task.dueDate.split('T')[0];
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(task);
    }
    return acc;
  }, {} as Record<string, Task[]>);

  return (
    <div className="space-y-6">
      {Object.entries(tasksByDate).map(([date, dateTasks]) => (
        <div key={date} className="space-y-3">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {formatDate(date)}
          </h2>
          <div className="space-y-2">
            {dateTasks.map(task => (
              <div
                key={task.id}
                onClick={() => onTaskClick(task)}
                className="card p-4 cursor-pointer"
              >
                <h3 className="font-medium text-gray-900 dark:text-white">{task.title}</h3>
                {task.description && (
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">
                    {task.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}