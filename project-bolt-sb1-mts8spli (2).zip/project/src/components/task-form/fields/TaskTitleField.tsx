import React from 'react';
import { Type } from 'lucide-react';

interface TaskTitleFieldProps {
  value: string;
  onChange: (value: string) => void;
}

export function TaskTitleField({ value, onChange }: TaskTitleFieldProps) {
  return (
    <div className="relative">
      <div className="absolute left-4 top-4">
        <Type className="w-5 h-5 text-gray-400 dark:text-gray-500" />
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Task title"
        className="w-full pl-12 pr-4 py-4 text-lg font-medium 
                 bg-gray-50 dark:bg-gray-800/50
                 border-0 border-b border-gray-200 dark:border-gray-700
                 rounded-t-xl rounded-b-none
                 focus:ring-0 focus:border-primary-500 dark:focus:border-primary-400
                 placeholder-gray-400 dark:placeholder-gray-500
                 transition-colors"
        autoFocus
      />
    </div>
  );
}