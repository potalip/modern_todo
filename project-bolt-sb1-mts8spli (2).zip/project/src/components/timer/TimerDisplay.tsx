import React from 'react';
import { Play, Pause, SkipForward, RotateCcw } from 'lucide-react';
import { formatTime } from '../../utils/timeUtils';
import { useTimerReset } from '../../hooks/useTimerReset';
import { TimerResetDialog } from '../dialogs/TimerResetDialog';

interface TimerDisplayProps {
  timeLeft: number;
  mode: 'work' | 'break';
  isRunning: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  onSkip: () => void;
  className?: string;
}

export function TimerDisplay({
  timeLeft,
  mode,
  isRunning,
  onTogglePlay,
  onReset,
  onSkip,
  className = '',
}: TimerDisplayProps) {
  const {
    showResetConfirm,
    handleResetRequest,
    handleResetConfirm,
    handleResetCancel,
  } = useTimerReset(onReset);

  return (
    <>
      <div className={`flex items-center gap-2 px-3 py-1.5 
                    bg-primary-50 dark:bg-primary-900/20
                    text-primary-700 dark:text-primary-300
                    rounded-lg ${className}`}>
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleResetRequest();
          }}
          className="p-1 hover:bg-primary-100 dark:hover:bg-primary-800/30 rounded-full
                   transition-transform active:scale-95"
          title="Reset timer"
        >
          <RotateCcw className="w-3 h-3" />
        </button>

        <span className="text-sm tabular-nums font-medium">
          {formatTime(timeLeft)}
        </span>
        <span className="text-xs text-primary-600/70 dark:text-primary-400/70">
          {mode === 'work' ? 'Focus' : 'Break'}
        </span>
        
        <div className="flex items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onTogglePlay();
            }}
            className="p-1 hover:bg-primary-100 dark:hover:bg-primary-800/30 rounded-full
                     transition-transform active:scale-95"
            title={isRunning ? "Pause timer" : "Resume timer"}
          >
            {isRunning ? (
              <Pause className="w-3 h-3" />
            ) : (
              <Play className="w-3 h-3" />
            )}
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSkip();
            }}
            className="p-1 hover:bg-primary-100 dark:hover:bg-primary-800/30 rounded-full
                     transition-transform active:scale-95"
            title="Skip to next phase"
          >
            <SkipForward className="w-3 h-3" />
          </button>
        </div>
      </div>

      {showResetConfirm && (
        <TimerResetDialog
          onConfirm={handleResetConfirm}
          onCancel={handleResetCancel}
        />
      )}
    </>
  );
}