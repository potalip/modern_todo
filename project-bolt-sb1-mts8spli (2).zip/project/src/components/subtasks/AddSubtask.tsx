import React, { useState } from 'react';
import { Plus } from 'lucide-react';

interface AddSubtaskProps {
  onAdd: (title: string) => void;
}

export function AddSubtask({ onAdd }: AddSubtaskProps) {
  const [title, setTitle] = useState('');

  const handleAdd = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (title.trim()) {
      onAdd(title.trim());
      setTitle('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      e.stopPropagation();
      handleAdd();
    }
  };

  return (
    <form onSubmit={handleAdd} className="flex items-center gap-2">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Add a subtask..."
        className="flex-grow px-3 py-1.5 text-sm
                 bg-white dark:bg-gray-800
                 border border-gray-200 dark:border-gray-700
                 rounded-lg
                 focus:border-primary-500 dark:focus:border-primary-400
                 focus:ring-1 focus:ring-primary-500/30
                 placeholder-gray-400 dark:placeholder-gray-500
                 transition-all duration-200"
        autoFocus
      />
      <button
        type="submit"
        disabled={!title.trim()}
        className="p-1.5 rounded-lg
                 text-primary-600 hover:text-primary-700
                 bg-primary-50 hover:bg-primary-100
                 dark:bg-primary-900/20 dark:hover:bg-primary-900/30
                 disabled:opacity-50 disabled:cursor-not-allowed
                 transition-colors"
        title="Add subtask"
      >
        <Plus className="w-4 h-4" />
      </button>
    </form>
  );
}