import React from 'react';
import { Category } from '../../../types';
import { Briefcase, User, InboxIcon } from 'lucide-react';

interface TaskCategoryFieldProps {
  value: Category;
  onChange: (value: Category) => void;
}

export function TaskCategoryField({ value, onChange }: TaskCategoryFieldProps) {
  const categories = [
    { id: 'inbox' as const, label: 'Inbox', icon: InboxIcon },
    { id: 'personal' as const, label: 'Personal', icon: User },
    { id: 'business' as const, label: 'Business', icon: Briefcase },
  ];

  return (
    <div className="space-y-1">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
        Category
      </label>
      <div className="flex gap-2">
        {categories.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-200 flex-1
              ${value === id
                ? 'bg-primary-600 text-white shadow-md scale-105'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:border-primary-300 dark:hover:border-primary-600'
              }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm font-medium">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}