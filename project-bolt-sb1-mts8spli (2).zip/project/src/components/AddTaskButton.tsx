import React from 'react';
import { Plus } from 'lucide-react';

interface AddTaskButtonProps {
  onClick: () => void;
}

export function AddTaskButton({ onClick }: AddTaskButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2 p-4 text-gray-600 hover:text-gray-800 hover:bg-gray-50 
                dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-800 
                rounded-lg transition-colors group"
    >
      <Plus className="w-5 h-5 text-primary-600 group-hover:scale-110 transition-transform" />
      <span className="font-medium">Add new task</span>
    </button>
  );
}