import React from 'react';
import { Task } from '../../types';

interface TaskFormFieldsProps {
  values: Partial<Task>;
  onChange: (field: keyof Task, value: any) => void;
}

export function TaskFormFields({ values, onChange }: TaskFormFieldsProps) {
  return (
    <div className="p-6 space-y-6">
      {/* Title & Description */}
      <div className="space-y-4">
        <div className="form-field">
          <input
            type="text"
            value={values.title || ''}
            onChange={(e) => onChange('title', e.target.value)}
            placeholder="Task title"
            className="w-full px-4 py-3 text-lg font-medium
                     bg-white dark:bg-gray-800
                     border border-gray-200 dark:border-gray-700
                     rounded-lg
                     focus:border-primary-500 dark:focus:border-primary-400
                     focus:ring-1 focus:ring-primary-500/30
                     placeholder-gray-400 dark:placeholder-gray-500
                     transition-all duration-200"
            autoFocus
          />
        </div>
        
        <div className="form-field">
          <textarea
            value={values.description || ''}
            onChange={(e) => onChange('description', e.target.value)}
            placeholder="Add a description..."
            className="w-full px-4 py-3
                     bg-white dark:bg-gray-800
                     border border-gray-200 dark:border-gray-700
                     rounded-lg
                     focus:border-primary-500 dark:focus:border-primary-400
                     focus:ring-1 focus:ring-primary-500/30
                     placeholder-gray-400 dark:placeholder-gray-500
                     resize-none
                     transition-all duration-200"
            rows={4}
          />
        </div>
      </div>

      {/* Category & Priority */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Category
          </label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => onChange('category', 'inbox')}
              className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                ${values.category === 'inbox' 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
            >
              Inbox
            </button>
            <button
              type="button"
              onClick={() => onChange('category', 'personal')}
              className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                ${values.category === 'personal'
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
            >
              Personal
            </button>
            <button
              type="button"
              onClick={() => onChange('category', 'business')}
              className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                ${values.category === 'business'
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
            >
              Business
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Priority
          </label>
          <select
            value={values.priority || 'medium'}
            onChange={(e) => onChange('priority', e.target.value)}
            className="w-full px-3 py-2 rounded-lg text-sm
                     bg-white dark:bg-gray-800
                     border border-gray-200 dark:border-gray-700
                     focus:border-primary-500 dark:focus:border-primary-400
                     focus:ring-1 focus:ring-primary-500/30
                     text-gray-900 dark:text-white"
          >
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Due Date */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          Due Date
        </label>
        <input
          type="date"
          value={values.dueDate || ''}
          onChange={(e) => onChange('dueDate', e.target.value)}
          className="w-full px-3 py-2 rounded-lg text-sm
                   bg-white dark:bg-gray-800
                   border border-gray-200 dark:border-gray-700
                   focus:border-primary-500 dark:focus:border-primary-400
                   focus:ring-1 focus:ring-primary-500/30
                   text-gray-900 dark:text-white"
        />
      </div>
    </div>
  );
}