import React from 'react';
import { Priority } from '../../../types';
import { Flag } from 'lucide-react';

interface TaskPriorityFieldProps {
  value: Priority;
  onChange: (value: Priority) => void;
}

export function TaskPriorityField({ value, onChange }: TaskPriorityFieldProps) {
  const priorities: { value: Priority; label: string; color: string }[] = [
    { value: 'urgent', label: 'Urgent', color: 'text-[rgb(var(--color-priority-high))]' },
    { value: 'high', label: 'High', color: 'text-[rgb(var(--color-priority-high))]' },
    { value: 'medium', label: 'Medium', color: 'text-[rgb(var(--color-priority-medium))]' },
    { value: 'low', label: 'Low', color: 'text-[rgb(var(--color-priority-low))]' },
  ];

  return (
    <div className="space-y-1">
      <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
        Priority
      </label>
      <div className="relative">
        <select
          id="priority"
          value={value}
          onChange={(e) => onChange(e.target.value as Priority)}
          className="input pl-10"
        >
          {priorities.map(({ value, label }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
        <Flag className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 
          ${priorities.find(p => p.value === value)?.color}`}
        />
      </div>
    </div>
  );
}