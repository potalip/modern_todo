import create from 'zustand';
import { TimerState } from '../types/timer';

interface TimerStore {
  activeTimers: Record<string, TimerState>;
  setTimer: (taskId: string, state: TimerState) => void;
  removeTimer: (taskId: string) => void;
  clearTimers: () => void;
}

export const useTimerStore = create<TimerStore>((set) => ({
  activeTimers: {},
  setTimer: (taskId, state) =>
    set((store) => ({
      activeTimers: { ...store.activeTimers, [taskId]: state },
    })),
  removeTimer: (taskId) =>
    set((store) => {
      const { [taskId]: _, ...rest } = store.activeTimers;
      return { activeTimers: rest };
    }),
  clearTimers: () => set({ activeTimers: {} }),
}));