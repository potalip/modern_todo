import { useState, useCallback } from 'react';

interface ConfirmationState {
  isOpen: boolean;
  resolve: ((value: boolean) => void) | null;
}

export function useConfirmation() {
  const [state, setState] = useState<ConfirmationState>({
    isOpen: false,
    resolve: null,
  });

  const confirm = useCallback(() => {
    return new Promise<boolean>((resolve) => {
      setState({ isOpen: true, resolve });
    });
  }, []);

  const handleConfirm = useCallback(() => {
    state.resolve?.(true);
    setState({ isOpen: false, resolve: null });
  }, [state]);

  const handleCancel = useCallback(() => {
    state.resolve?.(false);
    setState({ isOpen: false, resolve: null });
  }, [state]);

  return {
    isOpen: state.isOpen,
    confirm,
    handleConfirm,
    handleCancel,
  };
}