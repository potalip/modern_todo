import React from 'react';
import { SubTask } from '../../types';
import { SubtaskItem } from './SubtaskItem';

interface SubtaskListProps {
  subtasks: SubTask[];
  onToggleSubtask: (subtaskId: string) => void;
  onDeleteSubtask: (subtaskId: string) => void;
  onEditSubtask: (subtaskId: string, title: string) => void;
}

export function SubtaskList({
  subtasks,
  onToggleSubtask,
  onDeleteSubtask,
  onEditSubtask,
}: SubtaskListProps) {
  return (
    <div className="space-y-2">
      {subtasks.map((subtask) => (
        <SubtaskItem
          key={subtask.id}
          subtask={subtask}
          onToggle={onToggleSubtask}
          onDelete={onDeleteSubtask}
          onEdit={onEditSubtask}
        />
      ))}
    </div>
  );
}