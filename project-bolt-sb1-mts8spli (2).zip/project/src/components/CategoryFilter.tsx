import React from 'react';
import { Category } from '../types';
import { Briefcase, User, InboxIcon } from 'lucide-react';

interface CategoryFilterProps {
  selectedCategory: Category;
  onSelectCategory: (category: Category) => void;
}

export function CategoryFilter({ selectedCategory, onSelectCategory }: CategoryFilterProps) {
  const categories: { id: Category; label: string; icon: React.ReactNode }[] = [
    { id: 'inbox', label: 'All Tasks', icon: <InboxIcon className="w-4 h-4" /> },
    { id: 'personal', label: 'Personal', icon: <User className="w-4 h-4" /> },
    { id: 'business', label: 'Business', icon: <Briefcase className="w-4 h-4" /> },
  ];

  return (
    <div className="flex gap-2 mb-6">
      {categories.map(({ id, label, icon }) => (
        <button
          key={id}
          onClick={() => onSelectCategory(id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
            selectedCategory === id
              ? 'bg-primary text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
          }`}
        >
          {icon}
          <span className="text-sm font-medium">{label}</span>
        </button>
      ))}
    </div>
  );
}