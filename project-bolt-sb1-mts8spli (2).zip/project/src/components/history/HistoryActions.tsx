import React, { useState } from 'react';
import { Download, Trash2 } from 'lucide-react';
import { useHistoryStore } from '../../store/historyStore';
import { ConfirmDialog } from '../dialogs/ConfirmDialog';

interface HistoryActionsProps {
  onExport: () => void;
}

export function HistoryActions({ onExport }: HistoryActionsProps) {
  const clearHistory = useHistoryStore(state => state.clearHistory);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleClearHistory = () => {
    clearHistory();
    setShowClearConfirm(false);
  };

  return (
    <>
      <div className="flex gap-2">
        <button
          onClick={onExport}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium
                   text-primary-600 hover:text-primary-700 dark:text-primary-400
                   bg-primary-50 hover:bg-primary-100 
                   dark:bg-primary-900/20 dark:hover:bg-primary-900/30
                   rounded-lg transition-colors"
        >
          <Download className="w-4 h-4" />
          Export History
        </button>

        <button
          onClick={() => setShowClearConfirm(true)}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium
                   text-red-600 hover:text-red-700 dark:text-red-400
                   bg-red-50 hover:bg-red-100
                   dark:bg-red-900/20 dark:hover:bg-red-900/30
                   rounded-lg transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          Clear History
        </button>
      </div>

      {showClearConfirm && (
        <ConfirmDialog
          title="Clear History"
          message="This will permanently delete all task history. This action cannot be undone. Are you sure you want to continue?"
          confirmLabel="Clear History"
          type="danger"
          icon={Trash2}
          onConfirm={handleClearHistory}
          onCancel={() => setShowClearConfirm(false)}
        />
      )}
    </>
  );
}