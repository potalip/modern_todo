import React from 'react';
import { Task } from '../types';
import { X, Edit2, ListChecks } from 'lucide-react';
import { formatDate } from '../utils/dateUtils';
import { usePriorityColor } from '../hooks/usePriorityColor';
import { TimerStats } from './timer/TimerStats';

interface TaskModalProps {
  task: Task;
  onClose: () => void;
  onEdit: () => void;
  onSubtasksClick: () => void;
}

export function TaskModal({ task, onClose, onEdit, onSubtasksClick }: TaskModalProps) {
  const priorityColor = usePriorityColor(task.priority);
  const completedSubtasks = task.subtasks?.filter(st => st.completed).length ?? 0;
  const totalSubtasks = task.subtasks?.length ?? 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center p-4 animate-fade-in z-40">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full max-w-2xl mt-16 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Task Details
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <div className="space-y-4">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">
              {task.title}
            </h3>
            
            {task.description && (
              <p className="text-gray-600 dark:text-gray-300 whitespace-pre-wrap">
                {task.description}
              </p>
            )}

            <TimerStats taskId={task.id} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Status
              </h4>
              <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm
                ${task.completed
                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                  : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                }`}>
                {task.completed ? 'Completed' : 'In Progress'}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Priority
              </h4>
              <div className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-sm
                capitalize ${priorityColor}`}>
                {task.priority}
              </div>
            </div>

            {task.dueDate && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Due Date
                </h4>
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  {formatDate(task.dueDate)}
                </div>
              </div>
            )}

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Category
              </h4>
              <div className="text-sm text-gray-600 dark:text-gray-300 capitalize">
                {task.category}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-4">
            <button
              onClick={onSubtasksClick}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium
                       text-gray-700 dark:text-gray-200 
                       hover:bg-gray-100 dark:hover:bg-gray-700 
                       rounded-lg transition-colors"
            >
              <ListChecks className="w-4 h-4" />
              Subtasks
              {totalSubtasks > 0 && (
                <span className="ml-1 text-gray-500">
                  ({completedSubtasks}/{totalSubtasks})
                </span>
              )}
            </button>
          </div>

          <button
            onClick={onEdit}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium
                     bg-primary-600 text-white rounded-lg 
                     hover:bg-primary-700 transition-colors"
          >
            <Edit2 className="w-4 h-4" />
            Edit Task
          </button>
        </div>
      </div>
    </div>
  );
}