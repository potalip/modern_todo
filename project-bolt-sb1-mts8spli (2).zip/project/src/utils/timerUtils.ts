import { TimerSettings } from '../types/timer';

export const DEFAULT_TIMER_SETTINGS: TimerSettings = {
  workDuration: 45 * 60, // 45 minutes in seconds
  breakDuration: 15 * 60, // 15 minutes in seconds
};

export function calculateProgress(timeLeft: number, totalTime: number): number {
  return (timeLeft / totalTime) * 100;
}

export function getTimerModeLabel(mode: 'work' | 'break'): string {
  return mode === 'work' ? 'Focus Time' : 'Break Time';
}

export function shouldPlayNotification(
  prevTimeLeft: number,
  currentTimeLeft: number
): boolean {
  return prevTimeLeft > 0 && currentTimeLeft === 0;
}