import React from 'react';
import { Save, X } from 'lucide-react';

interface TaskFormFooterProps {
  isEditing: boolean;
  isValid: boolean;
  onCancel: () => void;
}

export function TaskFormFooter({ isEditing, isValid, onCancel }: TaskFormFooterProps) {
  return (
    <div className="sticky bottom-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4">
      <div className="flex justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="btn btn-secondary"
        >
          <X className="w-4 h-4 mr-2" />
          Cancel
        </button>
        <button
          type="submit"
          disabled={!isValid}
          className="btn btn-primary min-w-[120px]"
        >
          <Save className="w-4 h-4 mr-2" />
          {isEditing ? 'Save Changes' : 'Create Task'}
        </button>
      </div>
    </div>
  );
}