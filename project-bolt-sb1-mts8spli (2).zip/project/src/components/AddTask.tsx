import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Priority } from '../types';

interface AddTaskProps {
  onAddTask: (title: string, description: string, priority: Priority) => void;
}

export function AddTask({ onAddTask }: AddTaskProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      onAddTask(title, description, priority);
      setTitle('');
      setDescription('');
      setPriority('medium');
      setIsOpen(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full flex items-center gap-2 p-4 text-gray-600 hover:text-gray-800 hover:bg-gray-50 
                   dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-800 
                   rounded-lg transition-colors group"
      >
        <Plus className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
        <span className="font-medium">Add new task</span>
      </button>
    );
  }

  return (
    <div className="card p-4 animate-slide-up">
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Task title"
          className="input"
          autoFocus
        />
        
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Description (optional)"
          className="input resize-none"
          rows={3}
        />

        <div className="flex items-center gap-4">
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value as Priority)}
            className="input !w-auto"
          >
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>

          <div className="flex gap-2 ml-auto">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              Add Task
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}