import { Priority } from '../types';

export function usePriorityColor(priority: Priority): string {
  const colors = {
    urgent: 'text-[rgb(var(--color-priority-high))]',
    high: 'text-[rgb(var(--color-priority-high))]',
    medium: 'text-[rgb(var(--color-priority-medium))]',
    low: 'text-[rgb(var(--color-priority-low))]',
  };

  return colors[priority];
}