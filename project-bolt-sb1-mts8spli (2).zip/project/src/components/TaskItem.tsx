import React from 'react';
import { Task } from '../types';
import { CheckCircle2, Circle, Flag, Edit2, Trash2, ListChecks } from 'lucide-react';
import { usePriorityColor } from '../hooks/usePriorityColor';
import { getRelativeDateString } from '../utils/dateUtils';
import { TimerContainer } from './timer/TimerContainer';
import { TimeSpent } from './timer/TimeSpent';
import { TimerProvider } from './timer/TimerContext';
import { useConfirmation } from '../hooks/useConfirmation';
import { ConfirmDialog } from './dialogs/ConfirmDialog';

interface TaskItemProps {
  task: Task;
  onToggleComplete: (taskId: string) => void;
  onEdit: (task: Task) => void;
  onClick: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onSubtasksClick: (task: Task) => void;
}

export function TaskItem({
  task,
  onToggleComplete,
  onEdit,
  onClick,
  onDelete,
  onSubtasksClick,
}: TaskItemProps) {
  const priorityColor = usePriorityColor(task.priority);
  const completedSubtasks = task.subtasks.filter(st => st.completed).length;
  const { isOpen, confirm, handleConfirm, handleCancel } = useConfirmation();

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!task.completed) {
      const confirmed = await confirm();
      if (!confirmed) return;
    }
    
    onDelete(task.id);
  };

  return (
    <>
      <div 
        className="group relative hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all duration-200
                   hover:shadow-sm cursor-pointer"
        onClick={() => onClick(task)}
      >
        {/* Priority Indicator */}
        <div className={`absolute left-0 top-0 bottom-0 w-1 ${priorityColor.replace('text-', 'bg-')} 
                        opacity-50 group-hover:w-1.5 group-hover:opacity-100 transition-all duration-200`} />
        
        <div className="px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleComplete(task.id);
              }}
              className="flex-shrink-0 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700
                       transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              title={task.completed ? 'Mark as incomplete' : 'Mark as complete'}
            >
              {task.completed ? (
                <CheckCircle2 className="w-6 h-6 text-success-600 transition-transform group-hover:scale-110" />
              ) : (
                <Circle className="w-6 h-6 text-gray-400 group-hover:text-gray-600 
                                transition-all group-hover:scale-110" />
              )}
            </button>

            <div className="flex-grow min-w-0 group-hover:translate-x-1 transition-transform duration-200">
              <h3 className={`font-medium truncate ${
                task.completed ? 'text-gray-400 line-through' : 'text-gray-900 dark:text-gray-100'
              }`}>
                {task.title}
              </h3>
              {task.description && (
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1 mt-0.5">
                  {task.description}
                </p>
              )}
            </div>

            <div className="flex items-center gap-3 flex-shrink-0">
              <TimeSpent taskId={task.id} />
              
              <TimerProvider taskId={task.id}>
                <TimerContainer taskId={task.id} />
              </TimerProvider>

              {task.dueDate && (
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <span>{getRelativeDateString(task.dueDate)}</span>
                </div>
              )}
              
              {task.subtasks.length > 0 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSubtasksClick(task);
                  }}
                  className="flex items-center gap-1.5 px-2 py-1 text-sm
                           text-gray-600 dark:text-gray-300
                           hover:bg-gray-100 dark:hover:bg-gray-700
                           rounded-lg transition-all hover:scale-105
                           focus:outline-none focus:ring-2 focus:ring-primary-500/30"
                >
                  <ListChecks className="w-4 h-4" />
                  <span>{completedSubtasks}/{task.subtasks.length}</span>
                </button>
              )}

              <Flag className={`w-4 h-4 ${priorityColor}`} />
              
              <div className="opacity-0 group-hover:opacity-100 transition-all duration-200 
                            transform group-hover:translate-x-0 translate-x-4 flex gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(task);
                  }}
                  className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full
                           transition-all hover:scale-110
                           focus:outline-none focus:ring-2 focus:ring-primary-500/30"
                  title="Edit task"
                >
                  <Edit2 className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                </button>
                <button
                  onClick={handleDelete}
                  className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full
                           transition-all hover:scale-110
                           focus:outline-none focus:ring-2 focus:ring-error-500/30"
                  title="Delete task"
                >
                  <Trash2 className="w-4 h-4 text-error-600" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {isOpen && (
        <ConfirmDialog
          title="Delete Incomplete Task"
          message="This task is not marked as complete. Are you sure you want to delete it?"
          confirmLabel="Delete"
          type="danger"
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}
    </>
  );
}