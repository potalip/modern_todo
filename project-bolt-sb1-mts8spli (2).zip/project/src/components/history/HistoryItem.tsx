import React from 'react';
import { HistoryEntry } from '../../store/historyStore';
import { Clock, CheckCircle, Trash2, Calendar } from 'lucide-react';
import { formatDate } from '../../utils/dateUtils';
import { formatDuration } from '../../utils/timeUtils';

interface HistoryItemProps {
  entry: HistoryEntry;
}

export function HistoryItem({ entry }: HistoryItemProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 
                   dark:border-gray-700 p-4 space-y-3">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1">
          <h3 className="font-medium text-gray-900 dark:text-white">
            {entry.title}
          </h3>
          {entry.description && (
            <p className="text-sm text-gray-600 dark:text-gray-300">
              {entry.description}
            </p>
          )}
        </div>
        <div className={`px-2 py-1 rounded-full text-sm
          ${entry.status === 'completed'
            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
            : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
          }`}>
          <div className="flex items-center gap-1.5">
            {entry.status === 'completed' ? (
              <CheckCircle className="w-4 h-4" />
            ) : (
              <Trash2 className="w-4 h-4" />
            )}
            <span className="capitalize">{entry.status}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
        <div className="flex items-center gap-1.5">
          <Clock className="w-4 h-4" />
          <span>{formatDuration(entry.timeSpent)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4" />
          <span>{formatDate(entry.archivedAt)}</span>
        </div>
      </div>
    </div>
  );
}