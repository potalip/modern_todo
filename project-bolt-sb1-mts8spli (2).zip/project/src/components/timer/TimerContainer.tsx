import React, { useState } from 'react';
import { TimerDisplay } from './TimerDisplay';
import { TimerButton } from './TimerButton';
import { useTaskTimer } from '../../hooks/useTaskTimer';
import { useTimerStore } from '../../store/timerStore';

interface TimerContainerProps {
  taskId: string;
}

export function TimerContainer({ taskId }: TimerContainerProps) {
  const { state, actions } = useTaskTimer(taskId);
  const activeTimers = useTimerStore(store => store.activeTimers);
  const timerState = activeTimers[taskId] || state;
  const [isExpanded, setIsExpanded] = useState(timerState.isRunning);

  const handleStart = () => {
    setIsExpanded(true);
    actions.start();
  };

  const handleTogglePlay = () => {
    if (timerState.isRunning) {
      actions.pause();
    } else {
      actions.start();
    }
  };

  const handleReset = () => {
    actions.reset();
    setIsExpanded(false);
  };

  if (!isExpanded) {
    return <TimerButton onClick={handleStart} />;
  }

  return (
    <TimerDisplay
      timeLeft={timerState.timeLeft}
      mode={timerState.mode}
      isRunning={timerState.isRunning}
      onTogglePlay={handleTogglePlay}
      onReset={handleReset}
      onSkip={actions.switchMode}
      className="animate-fade-in"
    />
  );
}