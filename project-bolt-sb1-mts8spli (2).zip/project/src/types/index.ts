export type Priority = 'urgent' | 'high' | 'medium' | 'low';
export type Category = 'personal' | 'business' | 'inbox';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  dueDate: string | null;
  completed: boolean;
  createdAt: string;
  category: Category;
  subtasks: SubTask[];
  totalFocusTime: number; // Total focus time in seconds
}