import React from 'react';
import { Play, Clock } from 'lucide-react';

interface TimerButtonProps {
  onClick: () => void;
}

export function TimerButton({ onClick }: TimerButtonProps) {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className="flex items-center gap-1.5 px-2 py-1 text-sm
               text-gray-600 dark:text-gray-300
               hover:bg-gray-100 dark:hover:bg-gray-700
               rounded-lg transition-colors"
      title="Start timer"
    >
      <Clock className="w-4 h-4" />
      <Play className="w-3 h-3" />
    </button>
  );
}