import React, { useState } from 'react';
import { Task } from '../types';
import { TaskFormHeader } from './task-form/TaskFormHeader';
import { TaskFormFields } from './task-form/TaskFormFields';
import { TaskFormFooter } from './task-form/TaskFormFooter';

interface TaskFormProps {
  onSubmit: (task: Partial<Task>) => void;
  onCancel: () => void;
  initialValues?: Partial<Task>;
}

export function TaskForm({ onSubmit, onCancel, initialValues = {} }: TaskFormProps) {
  const [values, setValues] = useState<Partial<Task>>({
    title: '',
    description: '',
    priority: 'medium',
    dueDate: null,
    category: 'inbox',
    tags: [],
    subtasks: [],
    assignees: [],
    attachments: [],
    ...initialValues
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (values.title?.trim()) {
      onSubmit(values);
    }
  };

  const handleChange = (field: keyof Task, value: any) => {
    setValues(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 animate-fade-in z-50">
      <form 
        onSubmit={handleSubmit}
        className="bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full max-w-2xl overflow-hidden animate-slide-up"
      >
        <TaskFormHeader 
          isEditing={!!initialValues.id} 
          onClose={onCancel} 
        />

        <div className="max-h-[calc(100vh-12rem)] overflow-y-auto">
          <TaskFormFields 
            values={values} 
            onChange={handleChange} 
          />
        </div>

        <TaskFormFooter 
          isEditing={!!initialValues.id}
          isValid={!!values.title?.trim()}
          onCancel={onCancel}
        />
      </form>
    </div>
  );
}