import { useState, useCallback } from 'react';
import { Task, Priority, Category } from '../types';
import { storage } from '../services/storage';
import { useHistoryStore } from '../store/historyStore';
import { useTimerStore } from '../store/timerStore';

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>(() => storage.getTasks());
  const addHistoryEntry = useHistoryStore(state => state.addEntry);
  const { taskTimes, activeTimers } = useTimerStore();

  const saveTasks = useCallback((newTasks: Task[]) => {
    // Update total focus time for each task before saving
    const updatedTasks = newTasks.map(task => ({
      ...task,
      totalFocusTime: (taskTimes[task.id] || 0) + (activeTimers[task.id]?.totalFocusTime || 0),
    }));
    
    setTasks(updatedTasks);
    storage.saveTasks(updatedTasks);
  }, [taskTimes, activeTimers]);

  const addTask = useCallback((
    title: string,
    description: string = '',
    priority: Priority = 'medium',
    dueDate: string | null = null,
    category: Category = 'inbox',
  ) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      title,
      description,
      priority,
      dueDate,
      completed: false,
      createdAt: new Date().toISOString(),
      category,
      subtasks: [],
      totalFocusTime: 0,
    };
    saveTasks([...tasks, newTask]);
  }, [tasks, saveTasks]);

  const updateTask = useCallback((taskId: string, updates: Partial<Task>) => {
    const updatedTasks = tasks.map(task =>
      task.id === taskId ? { ...task, ...updates } : task
    );
    
    // If the task is being marked as completed, add it to history
    const task = tasks.find(t => t.id === taskId);
    if (task && !task.completed && updates.completed) {
      const updatedTask = updatedTasks.find(t => t.id === taskId)!;
      addHistoryEntry(updatedTask, 'completed');
    }
    
    saveTasks(updatedTasks);
  }, [tasks, saveTasks, addHistoryEntry]);

  const deleteTask = useCallback((taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      // Get the latest time data before adding to history
      const totalTime = (taskTimes[task.id] || 0) + (activeTimers[task.id]?.totalFocusTime || 0);
      const updatedTask = { ...task, totalFocusTime: totalTime };
      addHistoryEntry(updatedTask, 'deleted');
    }
    saveTasks(tasks.filter(task => task.id !== taskId));
  }, [tasks, saveTasks, addHistoryEntry, taskTimes, activeTimers]);

  const toggleTaskComplete = useCallback((taskId: string) => {
    saveTasks(tasks.map(task => {
      if (task.id === taskId) {
        const completed = !task.completed;
        const updatedTask = {
          ...task,
          completed,
          totalFocusTime: (taskTimes[task.id] || 0) + (activeTimers[task.id]?.totalFocusTime || 0),
        };
        
        if (completed) {
          addHistoryEntry(updatedTask, 'completed');
        }
        return updatedTask;
      }
      return task;
    }));
  }, [tasks, saveTasks, addHistoryEntry, taskTimes, activeTimers]);

  return {
    tasks,
    addTask,
    updateTask,
    toggleTaskComplete,
    deleteTask,
  };
}