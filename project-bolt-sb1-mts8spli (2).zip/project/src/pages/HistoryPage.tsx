import React, { useState, useMemo } from 'react';
import { useHistoryStore } from '../store/historyStore';
import { HistoryList } from '../components/history/HistoryList';
import { HistoryControls } from '../components/history/HistoryControls';
import { HistoryActions } from '../components/history/HistoryActions';
import { exportHistoryToCSV } from '../utils/exportUtils';

type SortField = 'archivedAt' | 'title' | 'timeSpent';
type SortOrder = 'asc' | 'desc';

export function HistoryPage() {
  const entries = useHistoryStore((state) => state.entries);
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'deleted'>('all');
  const [sortField, setSortField] = useState<SortField>('archivedAt');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const filteredAndSortedEntries = useMemo(() => {
    let filtered = entries;
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(entry => entry.status === statusFilter);
    }

    return [...filtered].sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'archivedAt':
          comparison = new Date(b.archivedAt).getTime() - new Date(a.archivedAt).getTime();
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
        case 'timeSpent':
          comparison = b.timeSpent - a.timeSpent;
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [entries, statusFilter, sortField, sortOrder]);

  const handleExport = () => {
    exportHistoryToCSV(filteredAndSortedEntries);
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 
                    dark:border-gray-700">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
                Task History
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                View and manage your completed and deleted tasks
              </p>
            </div>
            <HistoryActions onExport={handleExport} />
          </div>

          <HistoryControls
            statusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
            sortField={sortField}
            onSortFieldChange={setSortField}
            sortOrder={sortOrder}
            onSortOrderChange={setSortOrder}
          />
        </div>

        <div className="p-4">
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
            {filteredAndSortedEntries.length} {filteredAndSortedEntries.length === 1 ? 'task' : 'tasks'} found
          </div>
          
          <HistoryList entries={filteredAndSortedEntries} />
        </div>
      </div>
    </div>
  );
}