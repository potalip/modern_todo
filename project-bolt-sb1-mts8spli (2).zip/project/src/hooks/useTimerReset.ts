import { useCallback, useState } from 'react';

export function useTimerReset(onReset: () => void) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleResetRequest = useCallback(() => {
    setShowResetConfirm(true);
  }, []);

  const handleResetConfirm = useCallback(() => {
    onReset();
    setShowResetConfirm(false);
  }, [onReset]);

  const handleResetCancel = useCallback(() => {
    setShowResetConfirm(false);
  }, []);

  return {
    showResetConfirm,
    handleResetRequest,
    handleResetConfirm,
    handleResetCancel,
  };
}