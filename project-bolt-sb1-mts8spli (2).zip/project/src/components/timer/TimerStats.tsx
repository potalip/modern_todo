import React from 'react';
import { Clock } from 'lucide-react';
import { formatDuration } from '../../utils/timeUtils';
import { useTimerStore } from '../../store/timerStore';

interface TimerStatsProps {
  taskId: string;
}

export function TimerStats({ taskId }: TimerStatsProps) {
  const timer = useTimerStore(store => store.activeTimers[taskId]);
  
  if (!timer?.totalFocusTime) {
    return null;
  }

  return (
    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
      <Clock className="w-4 h-4" />
      <span>Focus time: {formatDuration(timer.totalFocusTime)}</span>
    </div>
  );
}