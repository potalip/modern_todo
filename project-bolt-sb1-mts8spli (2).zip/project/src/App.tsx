import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { TaskForm } from './components/TaskForm';
import { useTasks } from './hooks/useTasks';
import { Task, Category } from './types';
import { CategoryFilter } from './components/filters/CategoryFilter';
import { TaskModal } from './components/TaskModal';
import { AddTaskButton } from './components/AddTaskButton';
import { TaskContainer } from './components/TaskContainer';
import { SidePanel } from './components/layout/SidePanel';
import { SubtaskPanel } from './components/subtasks/SubtaskPanel';
import { HistoryPage } from './pages/HistoryPage';

export function App() {
  const { tasks, addTask, updateTask, toggleTaskComplete, deleteTask } = useTasks();
  const [darkMode, setDarkMode] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [view, setView] = useState<'list' | 'board' | 'calendar' | 'history'>('list');
  const [selectedCategory, setSelectedCategory] = useState<Category>('inbox');
  const [activeSubtaskTask, setActiveSubtaskTask] = useState<Task | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  const handleSubtasksClick = (task: Task) => {
    setActiveSubtaskTask(task);
    if (selectedTask) {
      setSelectedTask(null);
    }
  };

  const handleAddTask = (taskData: Partial<Task>) => {
    addTask(
      taskData.title!,
      taskData.description || '',
      taskData.priority || 'medium',
      taskData.dueDate || null,
      taskData.category || selectedCategory
    );
    setIsAddingTask(false);
  };

  const filteredTasks = tasks.filter(task => 
    selectedCategory === 'inbox' ? true : task.category === selectedCategory
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        view={view}
        setView={setView}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {view === 'history' ? (
          <HistoryPage />
        ) : (
          <div className="space-y-6">
            <CategoryFilter
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />

            {isAddingTask && (
              <TaskForm
                onSubmit={handleAddTask}
                onCancel={() => setIsAddingTask(false)}
                initialValues={{ category: selectedCategory }}
              />
            )}

            {editingTask && (
              <TaskForm
                initialValues={editingTask}
                onSubmit={(updates) => {
                  updateTask(editingTask.id, updates);
                  setEditingTask(null);
                }}
                onCancel={() => setEditingTask(null)}
              />
            )}

            {!isAddingTask && !editingTask && (
              <AddTaskButton onClick={() => setIsAddingTask(true)} />
            )}

            <TaskContainer
              view={view}
              tasks={filteredTasks}
              onToggleComplete={toggleTaskComplete}
              onEditTask={setEditingTask}
              onTaskClick={handleTaskClick}
              onDeleteTask={deleteTask}
              onSubtasksClick={handleSubtasksClick}
            />
          </div>
        )}
      </main>

      {selectedTask && (
        <TaskModal
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
          onEdit={() => {
            setEditingTask(selectedTask);
            setSelectedTask(null);
          }}
          onSubtasksClick={() => handleSubtasksClick(selectedTask)}
        />
      )}

      <SidePanel
        isOpen={!!activeSubtaskTask}
        onClose={() => setActiveSubtaskTask(null)}
      >
        {activeSubtaskTask && (
          <SubtaskPanel
            task={activeSubtaskTask}
            onClose={() => setActiveSubtaskTask(null)}
            onUpdateTask={updateTask}
          />
        )}
      </SidePanel>
    </div>
  );
}