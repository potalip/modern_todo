import { useState, useCallback } from 'react';
import { SubTask } from '../types';

export function useSubtasks(initialSubtasks: SubTask[] = []) {
  const [subtasks, setSubtasks] = useState<SubTask[]>(initialSubtasks);

  const addSubtask = useCallback((title: string) => {
    const newSubtask: SubTask = {
      id: crypto.randomUUID(),
      title,
      completed: false,
    };
    setSubtasks(prev => [...prev, newSubtask]);
    return newSubtask;
  }, []);

  const toggleSubtask = useCallback((id: string) => {
    setSubtasks(prev =>
      prev.map(subtask =>
        subtask.id === id
          ? { ...subtask, completed: !subtask.completed }
          : subtask
      )
    );
  }, []);

  const deleteSubtask = useCallback((id: string) => {
    setSubtasks(prev => prev.filter(subtask => subtask.id !== id));
  }, []);

  const editSubtask = useCallback((id: string, title: string) => {
    setSubtasks(prev =>
      prev.map(subtask =>
        subtask.id === id ? { ...subtask, title } : subtask
      )
    );
  }, []);

  return {
    subtasks,
    addSubtask,
    toggleSubtask,
    deleteSubtask,
    editSubtask,
  };
}