import React from 'react';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';

interface TimerControlsProps {
  isRunning: boolean;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
  onSkip: () => void;
}

export function TimerControls({
  isRunning,
  onStart,
  onPause,
  onReset,
  onSkip,
}: TimerControlsProps) {
  return (
    <div className="flex justify-center items-center gap-4">
      <button
        onClick={onReset}
        className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                 dark:hover:text-gray-200 transition-colors"
        title="Reset timer"
      >
        <RotateCcw className="w-5 h-5" />
      </button>

      <button
        onClick={isRunning ? onPause : onStart}
        className="p-4 bg-primary-600 hover:bg-primary-700 text-white 
                 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 
                 transition-all duration-200"
        title={isRunning ? 'Pause timer' : 'Start timer'}
      >
        {isRunning ? (
          <Pause className="w-6 h-6" />
        ) : (
          <Play className="w-6 h-6" />
        )}
      </button>

      <button
        onClick={onSkip}
        className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                 dark:hover:text-gray-200 transition-colors"
        title="Skip to next phase"
      >
        <SkipForward className="w-5 h-5" />
      </button>
    </div>
  );
}