import React from 'react';
import { User, Plus, X } from 'lucide-react';

interface Assignee {
  id: string;
  name: string;
  avatar?: string;
}

interface TaskAssigneesFieldProps {
  assignees: Assignee[];
  onChange: (assignees: Assignee[]) => void;
}

export function TaskAssigneesField({ assignees, onChange }: TaskAssigneesFieldProps) {
  const handleRemove = (id: string) => {
    onChange(assignees.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-2">
      <label className="form-label">Assignees</label>
      
      <div className="flex flex-wrap gap-2">
        {assignees.map(assignee => (
          <div
            key={assignee.id}
            className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 
                     rounded-full px-3 py-1.5 text-sm"
          >
            {assignee.avatar ? (
              <img
                src={assignee.avatar}
                alt={assignee.name}
                className="w-5 h-5 rounded-full"
              />
            ) : (
              <User className="w-4 h-4 text-gray-500" />
            )}
            <span>{assignee.name}</span>
            <button
              type="button"
              onClick={() => handleRemove(assignee.id)}
              className="hover:text-error-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
        
        <button
          type="button"
          className="flex items-center gap-1.5 text-sm text-primary-600 
                   hover:text-primary-700 dark:text-primary-400"
        >
          <Plus className="w-4 h-4" />
          Add assignee
        </button>
      </div>
    </div>
  );
}