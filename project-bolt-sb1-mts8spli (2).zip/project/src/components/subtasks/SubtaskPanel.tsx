import React, { useCallback, useState, useEffect } from 'react';
import { Task, SubTask } from '../../types';
import { SubtaskList } from './SubtaskList';
import { AddSubtask } from './AddSubtask';
import { ChevronLeft, ListChecks } from 'lucide-react';

interface SubtaskPanelProps {
  task: Task;
  onClose: () => void;
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void;
}

export function SubtaskPanel({ task, onClose, onUpdateTask }: SubtaskPanelProps) {
  const [subtasks, setSubtasks] = useState<SubTask[]>(task.subtasks || []);

  // Update local state when task changes
  useEffect(() => {
    setSubtasks(task.subtasks || []);
  }, [task.subtasks]);

  const handleAddSubtask = (title: string) => {
    const newSubtask: SubTask = {
      id: crypto.randomUUID(),
      title,
      completed: false,
    };
    const updatedSubtasks = [...subtasks, newSubtask];
    setSubtasks(updatedSubtasks);
    onUpdateTask(task.id, { subtasks: updatedSubtasks });
  };

  const handleToggleSubtask = (id: string) => {
    const updatedSubtasks = subtasks.map(subtask =>
      subtask.id === id ? { ...subtask, completed: !subtask.completed } : subtask
    );
    setSubtasks(updatedSubtasks);
    onUpdateTask(task.id, { subtasks: updatedSubtasks });
  };

  const handleDeleteSubtask = (id: string) => {
    const updatedSubtasks = subtasks.filter(subtask => subtask.id !== id);
    setSubtasks(updatedSubtasks);
    onUpdateTask(task.id, { subtasks: updatedSubtasks });
  };

  const handleEditSubtask = (id: string, title: string) => {
    const updatedSubtasks = subtasks.map(subtask =>
      subtask.id === id ? { ...subtask, title } : subtask
    );
    setSubtasks(updatedSubtasks);
    onUpdateTask(task.id, { subtasks: updatedSubtasks });
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.stopPropagation();
    }
  };

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown, true);
    return () => {
      document.removeEventListener('keydown', handleKeyDown, true);
    };
  }, []);

  const completedCount = subtasks.filter(st => st.completed).length;

  return (
    <div className="space-y-6" onClick={e => e.stopPropagation()}>
      <div className="flex items-center gap-4">
        <button
          onClick={onClose}
          className="btn-icon"
          title="Back to task"
        >
          <ChevronLeft className="w-5 h-5 text-gray-500 dark:text-gray-400" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Subtasks
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {task.title}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
          <ListChecks className="w-4 h-4" />
          <span>
            {completedCount} of {subtasks.length} completed
          </span>
        </div>

        <AddSubtask onAdd={handleAddSubtask} />

        <SubtaskList
          subtasks={subtasks}
          onToggleSubtask={handleToggleSubtask}
          onDeleteSubtask={handleDeleteSubtask}
          onEditSubtask={handleEditSubtask}
        />
      </div>
    </div>
  );
}