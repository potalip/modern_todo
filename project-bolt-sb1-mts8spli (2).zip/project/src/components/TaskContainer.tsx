import React from 'react';
import { Task } from '../types';
import { ListView } from './views/ListView';
import { BoardView } from './views/BoardView';
import { CalendarView } from './views/CalendarView';

interface TaskContainerProps {
  view: 'list' | 'board' | 'calendar';
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onEditTask: (task: Task) => void;
  onTaskClick: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onSubtasksClick: (task: Task) => void;
}

export function TaskContainer({
  view,
  tasks,
  onToggleComplete,
  onEditTask,
  onTaskClick,
  onDeleteTask,
  onSubtasksClick,
}: TaskContainerProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 dark:text-gray-400">
          No tasks found. Create a new task to get started!
        </p>
      </div>
    );
  }

  const viewProps = {
    tasks,
    onToggleComplete,
    onEditTask,
    onTaskClick,
    onDeleteTask,
    onSubtasksClick,
  };

  switch (view) {
    case 'board':
      return <BoardView {...viewProps} />;
    case 'calendar':
      return <CalendarView tasks={tasks} onTaskClick={onTaskClick} />;
    default:
      return <ListView {...viewProps} />;
  }
}