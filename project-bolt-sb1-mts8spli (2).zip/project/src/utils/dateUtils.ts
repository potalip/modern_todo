export function formatDate(dateString: string): string {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  if (!isValidDate(date)) return '';

  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function parseDate(dateString: string): Date | null {
  // Try parsing various date formats
  const formats = [
    // ISO format
    /^\d{4}-\d{2}-\d{2}$/,
    // US format
    /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/\d{4}$/,
    // European format
    /^(0?[1-9]|[12]\d|3[01])\/(0?[1-9]|1[0-2])\/\d{4}$/,
    // Natural language
    /^(today|tomorrow|yesterday)$/i,
  ];

  // Check if the string matches any of the formats
  for (const format of formats) {
    if (format.test(dateString)) {
      let date: Date;

      if (/^(today|tomorrow|yesterday)$/i.test(dateString)) {
        date = new Date();
        switch (dateString.toLowerCase()) {
          case 'tomorrow':
            date.setDate(date.getDate() + 1);
            break;
          case 'yesterday':
            date.setDate(date.getDate() - 1);
            break;
        }
      } else {
        date = new Date(dateString);
      }

      return isValidDate(date) ? date : null;
    }
  }

  return null;
}

export function isValidDate(date: Date): boolean {
  return date instanceof Date && !isNaN(date.getTime());
}

export function getRelativeDateString(dateString: string): string {
  const date = new Date(dateString);
  if (!isValidDate(date)) return '';

  const now = new Date();
  const diffTime = date.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  if (diffDays === -1) return 'Yesterday';
  if (diffDays > 0 && diffDays < 7) return `In ${diffDays} days`;
  if (diffDays < 0 && diffDays > -7) return `${Math.abs(diffDays)} days ago`;

  return formatDate(dateString);
}