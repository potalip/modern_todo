import React from 'react';
import { Task } from '../types';
import { TaskItem } from './TaskItem';

interface TaskListProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onEditTask: (task: Task) => void;
  onTaskClick: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onSubtasksClick: (task: Task) => void;
}

export function TaskList({
  tasks,
  onToggleComplete,
  onEditTask,
  onTaskClick,
  onDeleteTask,
  onSubtasksClick,
}: TaskListProps) {
  return (
    <div className="divide-y divide-gray-200 dark:divide-gray-700 rounded-lg overflow-hidden
                  border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm">
      {tasks.map((task, index) => (
        <TaskItem
          key={task.id}
          task={task}
          onToggleComplete={onToggleComplete}
          onEdit={onEditTask}
          onClick={onTaskClick}
          onDelete={onDeleteTask}
          onSubtasksClick={onSubtasksClick}
        />
      ))}
    </div>
  );
}