import React from 'react';
import { Clock } from 'lucide-react';
import { ConfirmDialog } from './ConfirmDialog';

interface TimerResetDialogProps {
  onConfirm: () => void;
  onCancel: () => void;
}

export function TimerResetDialog({ onConfirm, onCancel }: TimerResetDialogProps) {
  return (
    <ConfirmDialog
      title="Reset Timer"
      message="This will reset your timer and clear all progress. Are you sure you want to continue?"
      confirmLabel="Reset"
      type="warning"
      icon={Clock}
      onConfirm={onConfirm}
      onCancel={onCancel}
    />
  );
}