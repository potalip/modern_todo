import { useState, useEffect, useCallback } from 'react';
import { TimerState, TimerSettings } from '../types/timer';
import { useLocalStorage } from './useLocalStorage';
import { useTimerStore } from '../store/timerStore';
import { DEFAULT_TIMER_SETTINGS } from '../utils/timerUtils';

export function useTimer(taskId?: string) {
  const [settings] = useLocalStorage<TimerSettings>('pomodoro_settings', DEFAULT_TIMER_SETTINGS);
  const setTimer = useTimerStore(store => store.setTimer);
  const updateTaskTime = useTimerStore(store => store.updateTaskTime);
  const activeTimers = useTimerStore(store => store.activeTimers);
  
  const [state, setState] = useState<TimerState>(() => {
    if (taskId && activeTimers[taskId]) {
      return activeTimers[taskId];
    }
    return {
      isRunning: false,
      mode: 'work',
      timeLeft: settings.workDuration,
      totalFocusTime: 0,
      taskId,
    };
  });

  // Update store when state changes
  useEffect(() => {
    if (taskId) {
      setTimer(taskId, state);
      if (state.totalFocusTime > 0) {
        updateTaskTime(taskId, state.totalFocusTime);
      }
    }
  }, [taskId, state, setTimer, updateTaskTime]);

  const start = useCallback(() => {
    setState(prev => ({ ...prev, isRunning: true }));
  }, []);

  const pause = useCallback(() => {
    setState(prev => ({ ...prev, isRunning: false }));
  }, []);

  const reset = useCallback(() => {
    setState(prev => ({
      ...prev,
      isRunning: false,
      timeLeft: prev.mode === 'work' ? settings.workDuration : settings.breakDuration,
      totalFocusTime: 0,
    }));
    if (taskId) {
      updateTaskTime(taskId, 0);
    }
  }, [settings, taskId, updateTaskTime]);

  const switchMode = useCallback(() => {
    setState(prev => ({
      ...prev,
      mode: prev.mode === 'work' ? 'break' : 'work',
      timeLeft: prev.mode === 'work' ? settings.breakDuration : settings.workDuration,
      isRunning: false,
    }));
  }, [settings]);

  // Timer tick effect
  useEffect(() => {
    let interval: number;

    if (state.isRunning && state.timeLeft > 0) {
      interval = window.setInterval(() => {
        setState(prev => ({
          ...prev,
          timeLeft: prev.timeLeft - 1,
          totalFocusTime: prev.mode === 'work' ? prev.totalFocusTime + 1 : prev.totalFocusTime,
        }));
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [state.isRunning]);

  return {
    state,
    actions: {
      start,
      pause,
      reset,
      switchMode,
    },
  };
}