import React from 'react';
import { DatePicker } from '../../DatePicker';

interface TaskDateFieldProps {
  value: string;
  onChange: (value: string) => void;
}

export function TaskDateField({ value, onChange }: TaskDateFieldProps) {
  return (
    <div className="space-y-1">
      <DatePicker
        value={value}
        onChange={onChange}
        label="Due Date"
        id="taskDueDate"
      />
    </div>
  );
}