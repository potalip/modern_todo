import React from 'react';
import { Task } from '../../types';
import { TaskList } from '../TaskList';

interface ListViewProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onEditTask: (task: Task) => void;
  onTaskClick: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onSubtasksClick: (task: Task) => void;
}

export function ListView({
  tasks,
  onToggleComplete,
  onEditTask,
  onTaskClick,
  onDeleteTask,
  onSubtasksClick,
}: ListViewProps) {
  return (
    <TaskList
      tasks={tasks}
      onToggleComplete={onToggleComplete}
      onEditTask={onEditTask}
      onTaskClick={onTaskClick}
      onDeleteTask={onDeleteTask}
      onSubtasksClick={onSubtasksClick}
    />
  );
}