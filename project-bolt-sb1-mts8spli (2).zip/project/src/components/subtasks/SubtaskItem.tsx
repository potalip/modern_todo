import React, { useState } from 'react';
import { SubTask } from '../../types';
import { CheckCircle2, Circle, Pencil, X } from 'lucide-react';

interface SubtaskItemProps {
  subtask: SubTask;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, title: string) => void;
}

export function SubtaskItem({
  subtask,
  onToggle,
  onDelete,
  onEdit,
}: SubtaskItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(subtask.title);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editedTitle.trim()) {
      onEdit(subtask.id, editedTitle.trim());
      setIsEditing(false);
    }
  };

  if (isEditing) {
    return (
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <input
          type="text"
          value={editedTitle}
          onChange={(e) => setEditedTitle(e.target.value)}
          className="input flex-grow py-1 text-sm"
          autoFocus
        />
        <button
          type="submit"
          className="btn-icon text-success-600"
          title="Save changes"
        >
          <CheckCircle2 className="w-4 h-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            setIsEditing(false);
            setEditedTitle(subtask.title);
          }}
          className="btn-icon text-error-600"
          title="Cancel editing"
        >
          <X className="w-4 h-4" />
        </button>
      </form>
    );
  }

  return (
    <div className="flex items-center gap-2 group">
      <button
        onClick={() => onToggle(subtask.id)}
        className="flex-shrink-0"
        title={subtask.completed ? 'Mark as incomplete' : 'Mark as complete'}
      >
        {subtask.completed ? (
          <CheckCircle2 className="w-4 h-4 text-success-600" />
        ) : (
          <Circle className="w-4 h-4 text-gray-400" />
        )}
      </button>
      <span className={`flex-grow text-sm ${
        subtask.completed ? 'text-gray-400 line-through' : 'text-gray-700 dark:text-gray-300'
      }`}>
        {subtask.title}
      </span>
      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => setIsEditing(true)}
          className="btn-icon"
          title="Edit subtask"
        >
          <Pencil className="w-4 h-4 text-gray-500" />
        </button>
        <button
          onClick={() => onDelete(subtask.id)}
          className="btn-icon"
          title="Delete subtask"
        >
          <X className="w-4 h-4 text-error-600" />
        </button>
      </div>
    </div>
  );
}