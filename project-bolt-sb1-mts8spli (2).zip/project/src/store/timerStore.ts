import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { TimerState } from '../types/timer';

interface TimerStore {
  activeTimers: Record<string, TimerState>;
  taskTimes: Record<string, number>; // Store total focus time per task
  setTimer: (taskId: string, state: TimerState) => void;
  updateTaskTime: (taskId: string, time: number) => void;
  removeTimer: (taskId: string) => void;
  clearTimers: () => void;
}

export const useTimerStore = create<TimerStore>()(
  persist(
    (set) => ({
      activeTimers: {},
      taskTimes: {},
      setTimer: (taskId, state) =>
        set((store) => ({
          activeTimers: { ...store.activeTimers, [taskId]: state },
        })),
      updateTaskTime: (taskId, time) =>
        set((store) => ({
          taskTimes: { ...store.taskTimes, [taskId]: time },
        })),
      removeTimer: (taskId) =>
        set((store) => {
          const { [taskId]: _, ...restTimers } = store.activeTimers;
          return { activeTimers: restTimers };
        }),
      clearTimers: () => set({ activeTimers: {}, taskTimes: {} }),
    }),
    {
      name: 'timer-storage',
    }
  )
);