export interface TimerState {
  isRunning: boolean;
  mode: 'work' | 'break';
  timeLeft: number;
  totalFocusTime: number;
  taskId?: string;
}

export interface TimerSettings {
  workDuration: number;
  breakDuration: number;
}

export interface TimerStats {
  taskId: string;
  totalFocusTime: number;
  sessions: number;
  lastSession: string;
}