import React, { useState } from 'react';
import { Tag, Plus, X } from 'lucide-react';

interface TaskTagsFieldProps {
  tags: string[];
  onChange: (tags: string[]) => void;
}

export function TaskTagsField({ tags, onChange }: TaskTagsFieldProps) {
  const [newTag, setNewTag] = useState('');

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      onChange([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    onChange(tags.filter(t => t !== tag));
  };

  return (
    <div className="space-y-2">
      <label className="form-label">Tags</label>
      
      <div className="flex flex-wrap gap-2">
        {tags.map(tag => (
          <div
            key={tag}
            className="tag"
          >
            <Tag className="icon-sm" />
            <span>{tag}</span>
            <button
              type="button"
              onClick={() => handleRemoveTag(tag)}
              className="hover:text-primary-800 dark:hover:text-primary-200"
            >
              <X className="icon-sm" />
            </button>
          </div>
        ))}
        
        <div className="flex items-center gap-1">
          <input
            type="text"
            value={newTag}
            onChange={(e) => setNewTag(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
            placeholder="Add tag..."
            className="form-input !py-1 !px-2 text-sm min-w-[120px]"
          />
          <button
            type="button"
            onClick={handleAddTag}
            disabled={!newTag.trim()}
            className="p-1.5 text-primary-600 hover:text-primary-700 
                     disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="icon-sm" />
          </button>
        </div>
      </div>
    </div>
  );
}