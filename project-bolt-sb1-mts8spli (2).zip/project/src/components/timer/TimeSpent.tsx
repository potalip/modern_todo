import React from 'react';
import { Clock } from 'lucide-react';
import { formatDuration } from '../../utils/timeUtils';
import { useTimerStore } from '../../store/timerStore';

interface TimeSpentProps {
  taskId: string;
  className?: string;
}

export function TimeSpent({ taskId, className = '' }: TimeSpentProps) {
  const taskTime = useTimerStore(store => store.taskTimes[taskId] || 0);
  const activeTimer = useTimerStore(store => store.activeTimers[taskId]);
  
  // Combine stored time with current timer session
  const totalTime = taskTime + (activeTimer?.totalFocusTime || 0);
  
  if (!totalTime) {
    return null;
  }

  return (
    <div className={`flex items-center gap-1.5 px-2 py-1 text-sm
                   text-gray-600 dark:text-gray-300
                   bg-gray-50 dark:bg-gray-800
                   rounded-lg transition-colors ${className}`}>
      <Clock className="w-3.5 h-3.5" />
      <span className="tabular-nums">{formatDuration(totalTime)}</span>
    </div>
  );
}