import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Task } from '../types';
import { useTimerStore } from './timerStore';

export interface HistoryEntry extends Omit<Task, 'completed'> {
  archivedAt: string;
  status: 'completed' | 'deleted';
  timeSpent: number;
}

interface HistoryStore {
  entries: HistoryEntry[];
  addEntry: (task: Task, status: 'completed' | 'deleted') => void;
  clearHistory: () => void;
  removeEntry: (taskId: string) => void;
}

export const useHistoryStore = create<HistoryStore>()(
  persist(
    (set, get) => ({
      entries: [],
      addEntry: (task, status) => {
        const timerStore = useTimerStore.getState();
        const taskTime = timerStore.taskTimes[task.id] || 0;
        const activeTimer = timerStore.activeTimers[task.id];
        const totalTime = taskTime + (activeTimer?.totalFocusTime || 0);

        set((state) => {
          // Remove any existing entries for this task
          const filteredEntries = state.entries.filter(entry => entry.id !== task.id);
          
          // Create new entry
          const newEntry: HistoryEntry = {
            ...task,
            archivedAt: new Date().toISOString(),
            status,
            timeSpent: totalTime,
          };

          return {
            entries: [newEntry, ...filteredEntries],
          };
        });

        // Clear timer data for this task
        timerStore.removeTimer(task.id);
      },
      removeEntry: (taskId) =>
        set((state) => ({
          entries: state.entries.filter(entry => entry.id !== taskId),
        })),
      clearHistory: () => set({ entries: [] }),
    }),
    {
      name: 'task-history',
    }
  )
);