import React from 'react';
import { SubTask } from '../../../types';
import { SubtaskList } from '../../subtasks/SubtaskList';
import { AddSubtask } from '../../subtasks/AddSubtask';
import { useSubtasks } from '../../../hooks/useSubtasks';

interface TaskSubtasksFieldProps {
  subtasks: SubTask[];
  onChange: (subtasks: SubTask[]) => void;
}

export function TaskSubtasksField({ subtasks, onChange }: TaskSubtasksFieldProps) {
  const {
    subtasks: localSubtasks,
    addSubtask,
    toggleSubtask,
    deleteSubtask,
    editSubtask,
  } = useSubtasks(subtasks);

  // Sync local state with parent
  React.useEffect(() => {
    onChange(localSubtasks);
  }, [localSubtasks, onChange]);

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
        Subtasks
      </label>
      
      <div className="space-y-4">
        <SubtaskList
          subtasks={localSubtasks}
          onToggleSubtask={toggleSubtask}
          onDeleteSubtask={deleteSubtask}
          onEditSubtask={editSubtask}
        />
        
        <AddSubtask onAdd={addSubtask} />
      </div>
    </div>
  );
}