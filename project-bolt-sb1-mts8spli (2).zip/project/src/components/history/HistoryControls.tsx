import React from 'react';
import { Filter, ArrowUpDown, Clock, Calendar, AlignLeft, CheckCircle2, Trash2, ChevronDown } from 'lucide-react';
import { useClickOutside } from '../../hooks/useClickOutside';

interface HistoryControlsProps {
  statusFilter: 'all' | 'completed' | 'deleted';
  onStatusFilterChange: (value: 'all' | 'completed' | 'deleted') => void;
  sortField: 'archivedAt' | 'title' | 'timeSpent';
  onSortFieldChange: (field: 'archivedAt' | 'title' | 'timeSpent') => void;
  sortOrder: 'asc' | 'desc';
  onSortOrderChange: (order: 'asc' | 'desc') => void;
}

export function HistoryControls({
  statusFilter,
  onStatusFilterChange,
  sortField,
  onSortFieldChange,
  sortOrder,
  onSortOrderChange,
}: HistoryControlsProps) {
  const [isStatusOpen, setIsStatusOpen] = React.useState(false);
  const [isSortOpen, setIsSortOpen] = React.useState(false);
  const statusRef = React.useRef<HTMLDivElement>(null);
  const sortRef = React.useRef<HTMLDivElement>(null);

  useClickOutside(statusRef, () => setIsStatusOpen(false));
  useClickOutside(sortRef, () => setIsSortOpen(false));

  const statusOptions = [
    { value: 'all', label: 'All Tasks', icon: Filter },
    { value: 'completed', label: 'Completed', icon: CheckCircle2, color: 'text-green-500 dark:text-green-400' },
    { value: 'deleted', label: 'Deleted', icon: Trash2, color: 'text-red-500 dark:text-red-400' },
  ] as const;

  const sortOptions = [
    { value: 'archivedAt', label: 'Archive Date', icon: Calendar },
    { value: 'timeSpent', label: 'Time Spent', icon: Clock },
    { value: 'title', label: 'Title', icon: AlignLeft },
  ] as const;

  const currentStatus = statusOptions.find(option => option.value === statusFilter);
  const currentSort = sortOptions.find(option => option.value === sortField);

  return (
    <div className="flex flex-wrap items-center gap-3">
      {/* Status Filter Dropdown */}
      <div ref={statusRef} className="relative">
        <button
          onClick={() => setIsStatusOpen(!isStatusOpen)}
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium
                   bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700
                   text-gray-700 dark:text-gray-200
                   rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700
                   transition-colors min-w-[140px]"
        >
          <currentStatus.icon className={`w-4 h-4 ${currentStatus.color || 'text-gray-500 dark:text-gray-400'}`} />
          <span className="flex-grow text-left">{currentStatus.label}</span>
          <ChevronDown className={`w-4 h-4 text-gray-500 dark:text-gray-400 transition-transform ${isStatusOpen ? 'rotate-180' : ''}`} />
        </button>

        {isStatusOpen && (
          <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 
                        dark:border-gray-700 rounded-lg shadow-lg overflow-hidden">
            {statusOptions.map(option => (
              <button
                key={option.value}
                onClick={() => {
                  onStatusFilterChange(option.value);
                  setIsStatusOpen(false);
                }}
                className={`flex items-center gap-2 w-full px-3 py-2 text-sm
                         text-gray-700 dark:text-gray-200
                         hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors
                         ${option.value === statusFilter ? 'bg-gray-50 dark:bg-gray-700' : ''}`}
              >
                <option.icon className={`w-4 h-4 ${option.color || 'text-gray-500 dark:text-gray-400'}`} />
                {option.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Sort Controls */}
      <div className="flex items-center gap-2 ml-auto">
        <div ref={sortRef} className="relative">
          <button
            onClick={() => setIsSortOpen(!isSortOpen)}
            className="flex items-center gap-2 px-3 py-2 text-sm font-medium
                     bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700
                     text-gray-700 dark:text-gray-200
                     rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700
                     transition-colors min-w-[160px]"
          >
            <currentSort.icon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
            <span className="flex-grow text-left">Sort by {currentSort.label}</span>
            <ChevronDown className={`w-4 h-4 text-gray-500 dark:text-gray-400 transition-transform ${isSortOpen ? 'rotate-180' : ''}`} />
          </button>

          {isSortOpen && (
            <div className="absolute right-0 z-10 w-48 mt-1 bg-white dark:bg-gray-800 
                          border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg overflow-hidden">
              {sortOptions.map(option => (
                <button
                  key={option.value}
                  onClick={() => {
                    onSortFieldChange(option.value);
                    setIsSortOpen(false);
                  }}
                  className={`flex items-center gap-2 w-full px-3 py-2 text-sm
                           text-gray-700 dark:text-gray-200
                           hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors
                           ${option.value === sortField ? 'bg-gray-50 dark:bg-gray-700' : ''}`}
                >
                  <option.icon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                  {option.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={() => onSortOrderChange(sortOrder === 'asc' ? 'desc' : 'asc')}
          className={`p-2 rounded-lg transition-colors
                   bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700
                   hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm`}
          title={sortOrder === 'asc' ? 'Sort Ascending' : 'Sort Descending'}
        >
          <ArrowUpDown className={`w-4 h-4 transition-transform
            ${sortOrder === 'asc' ? 'text-primary-500 dark:text-primary-400' : 'text-gray-500 dark:text-gray-400'}`} />
        </button>
      </div>
    </div>
  );
}