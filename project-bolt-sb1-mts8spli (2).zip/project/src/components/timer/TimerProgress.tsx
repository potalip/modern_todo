import React from 'react';

interface TimerProgressProps {
  timeLeft: number;
  totalTime: number;
  mode: 'work' | 'break';
  className?: string;
}

export function TimerProgress({
  timeLeft,
  totalTime,
  mode,
  className = '',
}: TimerProgressProps) {
  const progress = (timeLeft / totalTime) * 100;

  return (
    <div className={`h-1 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden ${className}`}>
      <div
        className={`h-full transition-all duration-1000 ${
          mode === 'work'
            ? 'bg-primary-600'
            : 'bg-green-500'
        }`}
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}