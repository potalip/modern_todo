import React, { createContext, useContext, ReactNode } from 'react';
import { TimerState } from '../../types/timer';
import { useTimer } from '../../hooks/useTimer';

interface TimerContextValue {
  state: TimerState;
  actions: {
    start: () => void;
    pause: () => void;
    reset: () => void;
    switchMode: () => void;
  };
}

const TimerContext = createContext<TimerContextValue | null>(null);

interface TimerProviderProps {
  taskId?: string;
  children: ReactNode;
}

export function TimerProvider({ taskId, children }: TimerProviderProps) {
  const timer = useTimer(taskId);

  return (
    <TimerContext.Provider value={timer}>
      {children}
    </TimerContext.Provider>
  );
}

export function useTimerContext() {
  const context = useContext(TimerContext);
  if (!context) {
    throw new Error('useTimerContext must be used within a TimerProvider');
  }
  return context;
}