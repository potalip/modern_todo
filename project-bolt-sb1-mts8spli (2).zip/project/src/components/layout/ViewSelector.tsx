import React from 'react';
import { ListTodo, Calendar, Layout, History } from 'lucide-react';

interface ViewSelectorProps {
  view: 'list' | 'board' | 'calendar' | 'history';
  setView: (view: 'list' | 'board' | 'calendar' | 'history') => void;
}

export function ViewSelector({ view, setView }: ViewSelectorProps) {
  const views = [
    { id: 'list', icon: ListTodo, label: 'List view' },
    { id: 'board', icon: Layout, label: 'Board view' },
    { id: 'calendar', icon: Calendar, label: 'Calendar view' },
    { id: 'history', icon: History, label: 'History' },
  ] as const;

  return (
    <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-lg">
      {views.map(({ id, icon: Icon, label }) => (
        <button
          key={id}
          onClick={() => setView(id)}
          className={`
            p-2 rounded transition-all duration-200
            ${view === id ? 
              'bg-white dark:bg-gray-600 shadow-sm scale-105 text-primary-600 dark:text-primary-400' : 
              'text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 hover:bg-gray-50 dark:hover:bg-gray-700'
            }
          `}
          title={label}
        >
          <Icon className="w-5 h-5" />
        </button>
      ))}
    </div>
  );
}