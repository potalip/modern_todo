import { HistoryEntry } from '../store/historyStore';
import { formatDate } from './dateUtils';
import { formatDuration } from './timeUtils';

export function exportHistoryToCSV(entries: HistoryEntry[]): void {
  const headers = [
    'Title',
    'Description',
    'Status',
    'Category',
    'Time Spent',
    'Archived Date',
    'Created Date',
    'Priority',
  ];

  const rows = entries.map(entry => [
    entry.title,
    entry.description,
    entry.status,
    entry.category,
    formatDuration(entry.timeSpent),
    formatDate(entry.archivedAt),
    formatDate(entry.createdAt),
    entry.priority,
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `task-history-${formatDate(new Date().toISOString())}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}