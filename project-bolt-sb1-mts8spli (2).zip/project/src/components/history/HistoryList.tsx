import React from 'react';
import { HistoryEntry } from '../../store/historyStore';
import { HistoryItem } from './HistoryItem';

interface HistoryListProps {
  entries: HistoryEntry[];
}

export function HistoryList({ entries }: HistoryListProps) {
  if (entries.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500 dark:text-gray-400">
        No tasks in history
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {entries.map((entry) => (
        <HistoryItem key={`${entry.id}-${entry.status}`} entry={entry} />
      ))}
    </div>
  );
}