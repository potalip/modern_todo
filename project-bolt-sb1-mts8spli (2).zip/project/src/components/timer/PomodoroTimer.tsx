import React from 'react';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';
import { useTimer } from '../../hooks/useTimer';
import { formatTime } from '../../utils/timeUtils';

interface PomodoroTimerProps {
  taskId?: string;
  onFocusTimeUpdate?: (time: number) => void;
}

export function PomodoroTimer({ taskId, onFocusTimeUpdate }: PomodoroTimerProps) {
  const { state, actions } = useTimer(taskId);

  // Update parent component with focus time
  React.useEffect(() => {
    onFocusTimeUpdate?.(state.totalFocusTime);
  }, [state.totalFocusTime, onFocusTimeUpdate]);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 space-y-6">
      {/* Timer Display */}
      <div className="text-center">
        <div className="text-4xl font-bold tabular-nums">
          {formatTime(state.timeLeft)}
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400 mt-2">
          {state.mode === 'work' ? 'Focus Time' : 'Break Time'}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
        <div
          className={`h-full transition-all duration-1000 ${
            state.mode === 'work'
              ? 'bg-primary-600'
              : 'bg-green-500'
          }`}
          style={{
            width: `${(state.timeLeft / (state.mode === 'work' ? 2700 : 900)) * 100}%`,
          }}
        />
      </div>

      {/* Controls */}
      <div className="flex justify-center items-center gap-4">
        <button
          onClick={actions.reset}
          className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                   dark:hover:text-gray-200 transition-colors"
          title="Reset timer"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        <button
          onClick={state.isRunning ? actions.pause : actions.start}
          className="p-4 bg-primary-600 hover:bg-primary-700 text-white 
                   rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 
                   transition-all duration-200"
          title={state.isRunning ? 'Pause timer' : 'Start timer'}
        >
          {state.isRunning ? (
            <Pause className="w-6 h-6" />
          ) : (
            <Play className="w-6 h-6" />
          )}
        </button>

        <button
          onClick={actions.switchMode}
          className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                   dark:hover:text-gray-200 transition-colors"
          title="Skip to next phase"
        >
          <SkipForward className="w-5 h-5" />
        </button>
      </div>

      {/* Stats */}
      {state.mode === 'work' && (
        <div className="text-center text-sm text-gray-500 dark:text-gray-400">
          Total focus time: {formatTime(state.totalFocusTime)}
        </div>
      )}
    </div>
  );
}