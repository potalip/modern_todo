import React, { useRef } from 'react';
import { Paperclip, File, X } from 'lucide-react';

interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
}

interface TaskAttachmentsFieldProps {
  attachments: Attachment[];
  onChange: (attachments: Attachment[]) => void;
}

export function TaskAttachmentsField({ attachments, onChange }: TaskAttachmentsFieldProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newAttachments = files.map(file => ({
      id: crypto.randomUUID(),
      name: file.name,
      size: file.size,
      type: file.type,
      url: URL.createObjectURL(file)
    }));
    
    onChange([...attachments, ...newAttachments]);
  };

  const handleRemove = (id: string) => {
    onChange(attachments.filter(a => a.id !== id));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="space-y-3">
      <label className="form-label">Attachments</label>
      
      <div className="space-y-2">
        {attachments.map(file => (
          <div
            key={file.id}
            className="flex items-center gap-3 p-2 bg-gray-50 dark:bg-gray-700/50 
                     rounded-lg border border-gray-200 dark:border-gray-600"
          >
            <File className="w-5 h-5 text-gray-500" />
            <div className="flex-grow min-w-0">
              <div className="truncate text-sm font-medium">{file.name}</div>
              <div className="text-xs text-gray-500">{formatFileSize(file.size)}</div>
            </div>
            <button
              type="button"
              onClick={() => handleRemove(file.id)}
              className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileChange}
      />
      
      <button
        type="button"
        onClick={() => fileInputRef.current?.click()}
        className="flex items-center gap-2 text-sm text-primary-600 
                 hover:text-primary-700 dark:text-primary-400"
      >
        <Paperclip className="w-4 h-4" />
        Attach files
      </button>
    </div>
  );
}