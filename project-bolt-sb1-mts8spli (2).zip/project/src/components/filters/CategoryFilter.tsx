import React from 'react';
import { Category } from '../../types';
import { Briefcase, User, InboxIcon } from 'lucide-react';

interface CategoryFilterProps {
  selectedCategory: Category;
  onSelectCategory: (category: Category) => void;
}

export function CategoryFilter({ selectedCategory, onSelectCategory }: CategoryFilterProps) {
  const categories = [
    { id: 'inbox' as const, label: 'All Tasks', icon: InboxIcon },
    { id: 'personal' as const, label: 'Personal', icon: User },
    { id: 'business' as const, label: 'Business', icon: Briefcase },
  ];

  const getCategoryColor = (id: Category) => {
    switch (id) {
      case 'personal':
        return 'text-[rgb(var(--color-personal))]';
      case 'business':
        return 'text-[rgb(var(--color-business))]';
      default:
        return 'text-gray-400 dark:text-gray-500';
    }
  };

  const getButtonStyles = (id: Category) => {
    const isSelected = selectedCategory === id;
    const baseStyles = 'flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 transform';
    
    if (isSelected) {
      return `${baseStyles} 
        ${id === 'personal' ? 'bg-[rgb(var(--color-personal))]' : 
          id === 'business' ? 'bg-[rgb(var(--color-business))]' : 
          'bg-primary-600'} 
        text-white shadow-md scale-105`;
    }

    return `${baseStyles} 
      bg-white dark:bg-gray-800 
      text-gray-700 dark:text-gray-300 
      hover:bg-opacity-90 
      border border-gray-200 dark:border-gray-700
      ${id === 'personal' ? 'hover:border-[rgb(var(--color-personal))]' :
        id === 'business' ? 'hover:border-[rgb(var(--color-business))]' :
        'hover:border-primary-300'} 
      dark:hover:border-opacity-50`;
  };

  return (
    <div className="flex gap-2 mb-6">
      {categories.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onSelectCategory(id)}
          className={getButtonStyles(id)}
        >
          <Icon className={`w-4 h-4 ${
            selectedCategory === id ? 'text-white' : getCategoryColor(id)
          }`} />
          <span className="text-sm font-medium">{label}</span>
        </button>
      ))}
    </div>
  );
}