import { useEffect } from 'react';
import { useTimerStore } from '../store/timerStore';
import { useTimer } from './useTimer';

export function useTaskTimer(taskId: string) {
  const updateTaskTime = useTimerStore(state => state.updateTaskTime);
  const timer = useTimer(taskId);

  // Update total focus time whenever it changes
  useEffect(() => {
    if (taskId) {
      updateTaskTime(taskId, timer.state.totalFocusTime);
    }
  }, [taskId, timer.state.totalFocusTime, updateTaskTime]);

  return timer;
}