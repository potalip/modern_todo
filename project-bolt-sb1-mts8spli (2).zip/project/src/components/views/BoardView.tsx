import React from 'react';
import { Task } from '../../types';

interface BoardViewProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onEditTask: (task: Task) => void;
  onTaskClick: (task: Task) => void;
}

export function BoardView({ tasks, onToggleComplete, onEditTask, onTaskClick }: BoardViewProps) {
  const columns = {
    todo: tasks.filter(task => !task.completed),
    done: tasks.filter(task => task.completed),
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {Object.entries(columns).map(([status, statusTasks]) => (
        <div key={status} className="space-y-4">
          <h2 className="text-lg font-semibold capitalize text-gray-900 dark:text-white">
            {status}
            <span className="ml-2 text-sm text-gray-500">({statusTasks.length})</span>
          </h2>
          <div className="space-y-3">
            {statusTasks.map(task => (
              <div
                key={task.id}
                className="card p-4 cursor-pointer"
                onClick={() => onTaskClick(task)}
              >
                <h3 className="font-medium text-gray-900 dark:text-white">{task.title}</h3>
                {task.description && (
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">
                    {task.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}