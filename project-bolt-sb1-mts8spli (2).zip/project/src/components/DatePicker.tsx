import React from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';
import { formatDate, isValidDate } from '../utils/dateUtils';

interface DatePickerProps {
  value: string;
  onChange: (date: string) => void;
  label?: string;
  id?: string;
}

export function DatePicker({ value, onChange, label, id = 'datePicker' }: DatePickerProps) {
  const datePickerRef = React.useRef<HTMLDivElement>(null);
  const [isOpen, setIsOpen] = React.useState(false);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (datePickerRef.current && !datePickerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const date = e.target.value;
    if (date && isValidDate(new Date(date))) {
      onChange(date);
      setIsOpen(false);
    }
  };

  const toggleCalendar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="relative" ref={datePickerRef}>
      {label && (
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          {label}
        </label>
      )}
      
      <div className="relative">
        <input
          type="date"
          id={id}
          value={value}
          onChange={handleDateChange}
          className="input appearance-none pr-10"
        />
        <button
          type="button"
          onClick={toggleCalendar}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
        >
          <CalendarIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
        </button>
      </div>

      {value && (
        <div className="absolute top-full left-0 mt-1 text-sm text-gray-500 dark:text-gray-400">
          {formatDate(value)}
        </div>
      )}
    </div>
  );
}